import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '1mb' }));

  // In-memory store for the current system state
  let systemState = {
    connected: false,
    lastUpdate: null,
    os: "",
    cpuUsage: 0,
    memory: {
      total: 0,
      used: 0,
      percent: 0
    },
    processes: [],
    history: [] // Keep last 20 samples for charts
  };

  // API Routes
  app.get("/api/status", (req, res) => {
    res.json(systemState);
  });

  app.get("/api/agent-source", (req, res) => {
    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    const host = req.headers.host;
    const origin = `${protocol}://${host}`;
    
    const script = `import psutil
import requests
import time
import json

API_URL = "${origin}/api/report"

def gather_data():
    memory = psutil.virtual_memory()
    processes = []
    
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
        try:
            info = proc.info
            processes.append({
                "pid": info['pid'],
                "name": info['name'],
                "cpu": info['cpu_percent'],
                "memory": info['memory_info'].rss / (1024 * 1024)
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
            
    return {
        "os": "Windows/Machine",
        "cpuUsage": psutil.cpu_percent(interval=1),
        "memory": {
            "total": memory.total / (1024 * 1024),
            "used": memory.used / (1024 * 1024),
            "percent": memory.percent
        },
        "processes": sorted(processes, key=lambda x: x['memory'], reverse=True)[:50]
    }

print(f"Connecting to PC Pulse at {API_URL}...")

while True:
    try:
        data = gather_data()
        requests.post(API_URL, json=data)
        time.sleep(2)
    except Exception as e:
        print(f"Sync error: {e}")
        time.sleep(5)`;
    
    res.setHeader('Content-Type', 'text/plain');
    res.send(script);
  });

  app.post("/api/report", (req, res) => {
    const { os, cpuUsage, memory, processes } = req.body;
    
    systemState = {
      ...systemState,
      connected: true,
      lastUpdate: new Date().toISOString(),
      os,
      cpuUsage,
      memory,
      processes: processes || []
    };

    // Keep history for charts
    const newHistoryPoint = {
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      cpu: cpuUsage,
      ram: memory.percent
    };

    systemState.history = [...systemState.history, newHistoryPoint].slice(-30);

    res.json({ success: true });
  });

  app.post("/api/disconnect", (req, res) => {
    systemState.connected = false;
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
