import { useState, useEffect, useCallback, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  Terminal, 
  ShieldCheck, 
  Info, 
  Settings, 
  RefreshCcw,
  AlertTriangle,
  Zap,
  Trash2,
  Monitor
} from "lucide-react";
import { cn } from "./lib/utils";
import { GoogleGenAI, Type } from "@google/genai";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from "recharts";

// Interfaces
interface SystemMemory {
  total: number;
  used: number;
  percent: number;
}

interface Process {
  pid: number;
  name: string;
  cpu: number;
  memory: number;
  status?: "safe" | "system" | "suspicious" | "unknown";
  category?: string;
  description?: string;
}

interface SystemState {
  connected: boolean;
  lastUpdate: string | null;
  os: string;
  cpuUsage: number;
  memory: SystemMemory;
  processes: Process[];
  history: { time: string; cpu: number; ram: number }[];
}

interface AnalysisCache {
  [name: string]: {
    status: "safe" | "system" | "suspicious" | "unknown";
    category: string;
    description: string;
  };
}

export default function App() {
  const [data, setData] = useState<SystemState | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisCache>({});
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showAgentModal, setShowAgentModal] = useState(false);
  const [selectedProcess, setSelectedProcess] = useState<Process | null>(null);

  // Poll server for data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("/api/status");
        const json = await res.json();
        setData(json);
      } catch (err) {
        console.error("Failed to fetch status:", err);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, []);

  // AI Analysis of processes
  const analyzeProcesses = useCallback(async (processes: Process[]) => {
    if (isAnalyzing || processes.length === 0) return;
    
    const unknowns = processes.filter(p => !analysis[p.name]);
    if (unknowns.length === 0) return;

    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const processNames = Array.from(new Set(unknowns.map(p => p.name))).slice(0, 50);
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analyze these computer process names and categorize them. 
        For each process, provide a category (System, User, Utility, Gaming, Browser, etc), 
        a safety status (safe, system, suspicious), and a short 1-sentence description.
        
        Processes: ${processNames.join(", ")}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              results: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    status: { type: Type.STRING, enum: ["safe", "system", "suspicious", "unknown"] },
                    category: { type: Type.STRING },
                    description: { type: Type.STRING }
                  },
                  required: ["name", "status", "category", "description"]
                }
              }
            },
            required: ["results"]
          }
        }
      });

      const result = JSON.parse(response.text);
      const newCache = { ...analysis };
      result.results.forEach((item: any) => {
        newCache[item.name] = {
          status: item.status,
          category: item.category,
          description: item.description
        };
      });
      setAnalysis(newCache);
    } catch (err) {
      console.error("AI Analysis failed:", err);
    } finally {
      setIsAnalyzing(false);
    }
  }, [analysis, isAnalyzing]);

  // Clean up unused memory logic (simulated action)
  const [cleaningStatus, setCleaningStatus] = useState<string | null>(null);
  const handleOptimize = () => {
    setCleaningStatus("Optimizing system memory...");
    setTimeout(() => {
      setCleaningStatus("Cleaning standby logs...");
      setTimeout(() => {
        setCleaningStatus("Success: Flushed 420MB of cache.");
        setTimeout(() => setCleaningStatus(null), 3000);
      }, 1500);
    }, 1000);
  };

  const downloadAgent = () => {
    const script = agentScript(window.location.origin);
    const blob = new Blob([script], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pc_pulse_agent.py';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadWindowsApp = () => {
    const scriptSource = agentScript(window.location.origin);
    // Escape single quotes for PowerShell
    const escapedScript = scriptSource.replace(/'/g, "''");

    const launcherContent = `@echo off
title PC Pulse Pro - Local Agent
echo ========================================
echo   PC PULSE PRO - Windows Launcher
echo ========================================
echo.
echo [1/2] Verifying Python Environment...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found! Please install from python.org
    pause
    exit /b
)
echo [2/2] Installing Dependencies (psutil, requests)...
pip install psutil requests >nul 2>&1

echo.
echo [3/3] Generating Agent Script...
powershell -Command "$s = @'
${escapedScript}
'@; $s | Out-File -Encoding utf8 'pc_pulse_agent.py'"

echo.
echo Starting Sync Pipeline...
python pc_pulse_agent.py
pause`;

    const blob = new Blob([launcherContent], { type: 'application/x-bat' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Launch_PC_Pulse.bat';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadUninstaller = () => {
    const uninstallerContent = `@echo off
title PC Pulse Pro - Uninstaller
echo ========================================
echo   PC PULSE PRO - Cleanup Utility
echo ========================================
echo.
echo [1/2] Terminating active agent processes...
taskkill /F /FI "IMAGENAME eq python.exe" /FI "WINDOWTITLE eq PC Pulse Pro - Local Agent" >nul 2>&1
echo [2/2] Removing agent files...
if exist "pc_pulse_agent.py" (
    del "pc_pulse_agent.py"
    echo [SUCCESS] pc_pulse_agent.py removed.
) else (
    echo [INFO] No agent script found to delete.
)
echo.
echo Cleanup complete. You can now delete this uninstaller file.
echo.
pause`;

    const blob = new Blob([uninstallerContent], { type: 'application/x-bat' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Uninstall_PC_Pulse.bat';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 md:p-8 overflow-hidden">
      {/* Mesh Gradients */}
      <div className="mesh-gradient-1" />
      <div className="mesh-gradient-2" />

      {/* Main Glass Container */}
      <div className="glass-main w-full max-w-7xl h-[95vh] md:h-[90vh] flex flex-col overflow-hidden relative z-10 shrink-0">
        
        {/* Header */}
        <header className="h-20 border-b border-white/10 flex items-center justify-between px-8 bg-white/5">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center shadow-lg">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">PC Pulse <span className="text-cyan-400">Pro</span></h1>
              <p className="text-[10px] text-white/50 uppercase tracking-widest font-bold">
                {data?.connected ? `CONNECTED: ${data.os || "Active"}` : "OFFLINE: DISCONNECTED"}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex px-4 py-2 bg-white/5 rounded-full border border-white/10 items-center gap-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                data?.connected ? "bg-emerald-400 animate-pulse" : "bg-red-500"
              )} />
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/70">
                {data?.connected ? "Live Sync Active" : "Disconnected"}
              </span>
            </div>
            
            <button 
              onClick={() => setShowAgentModal(true)}
              className="p-2 hover:bg-white/10 rounded-full transition-colors text-white/60 hover:text-white"
            >
              <Terminal className="w-5 h-5" />
            </button>
            
            <button 
              onClick={handleOptimize}
              className="px-6 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-900 font-bold rounded-full transition-all text-sm shadow-xl shadow-cyan-900/20 active:scale-95"
            >
              Boost Memory
            </button>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-auto p-8 flex flex-col gap-8 custom-scrollbar">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard 
              icon={<Cpu className="w-5 h-5 text-cyan-400" />}
              label="CPU LOAD"
              value={`${data?.cpuUsage.toFixed(1) || 0}%`}
              subtext="Real-time demand"
            />
            <StatCard 
              icon={<HardDrive className="w-5 h-5 text-blue-400" />}
              label="MEMORY (RAM)"
              value={`${data?.memory.percent.toFixed(1) || 0}%`}
              subtext={`${((data?.memory.used || 0) / 1024).toFixed(1)}GB / ${((data?.memory.total || 0) / 1024).toFixed(1)}GB`}
            />
            <StatCard 
              icon={<Monitor className="w-5 h-5 text-teal-400" />}
              label="PROCESSES"
              value={(data?.processes.length || 0).toString()}
              subtext="Active threads"
            />
            <StatCard 
              icon={<ShieldCheck className="w-5 h-5 text-emerald-400" />}
              label="SECURITY"
              value="STABLE"
              subtext="Integrity verified"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Col: Charts & Explorer */}
            <div className="lg:col-span-8 space-y-8">
              {/* Telemetry */}
              <div className="glass-panel overflow-hidden">
                <div className="p-6 border-b border-white/10 flex items-center justify-between">
                  <h3 className="font-bold flex items-center gap-2 text-sm italic tracking-widest uppercase">
                    <Activity className="w-4 h-4 text-cyan-400" /> SYSTEM TELEMETRY
                  </h3>
                  <div className="flex gap-4 label-caps">
                    <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span> CPU</div>
                    <div className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span> RAM</div>
                  </div>
                </div>
                <div className="h-[280px] w-full p-4 pr-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data?.history || []}>
                      <defs>
                        <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#22d3ee" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorRam" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" vertical={false} />
                      <XAxis dataKey="time" stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} domain={[0, 100]} />
                      <Tooltip contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #ffffff10", borderRadius: "12px" }} />
                      <Area type="monotone" dataKey="cpu" stroke="#22d3ee" strokeWidth={2} fill="url(#colorCpu)" animationDuration={1000} />
                      <Area type="monotone" dataKey="ram" stroke="#3b82f6" strokeWidth={2} fill="url(#colorRam)" animationDuration={1000} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Process Table */}
              <div className="glass-panel overflow-hidden">
                <div className="p-6 border-b border-white/10 flex justify-between items-center">
                  <h3 className="font-bold flex items-center gap-2 text-sm italic tracking-widest uppercase text-white/80">
                    <Zap className="w-4 h-4 text-cyan-400" /> ACTIVE PROCESSES
                  </h3>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => data?.processes && analyzeProcesses(data.processes)}
                      disabled={isAnalyzing || !data?.connected}
                      className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 transition-colors disabled:opacity-30 flex items-center gap-2"
                    >
                      {isAnalyzing ? <RefreshCcw className="w-3 h-3 animate-spin" /> : <ShieldCheck className="w-3 h-3" />}
                      Audit Fleet
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="label-caps">
                        <th className="px-6 py-4 font-semibold border-b border-white/5">Process Name</th>
                        <th className="px-6 py-4 font-semibold border-b border-white/5">CPU</th>
                        <th className="px-6 py-4 font-semibold border-b border-white/5 text-right">Memory</th>
                        <th className="px-6 py-4 font-semibold border-b border-white/5 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="text-sm">
                      {data?.processes.sort((a,b) => b.memory - a.memory).slice(0, 15).map((p) => {
                        const info = analysis[p.name];
                        return (
                          <tr 
                            key={`${p.pid}-${p.name}`} 
                            onClick={() => setSelectedProcess({ ...p, ...info })}
                            className="group border-b border-white/5 hover:bg-white/5 transition-colors cursor-pointer"
                          >
                            <td className="px-6 py-4">
                              <div className="font-bold">{p.name}</div>
                              <div className="text-[10px] text-white/40 uppercase font-bold tracking-wider">{info?.category || `PID: ${p.pid}`}</div>
                            </td>
                            <td className="px-6 py-4 font-mono text-xs text-white/80">{p.cpu.toFixed(1)}%</td>
                            <td className="px-6 py-4 text-right font-mono text-xs">{(p.memory / 1024).toFixed(1)} GB</td>
                            <td className="px-6 py-4 text-right">
                              <StatusBadge status={info?.status || (data.connected ? "unknown" : "idle")} />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Right Col: AI & Selection */}
            <div className="lg:col-span-4 space-y-8">
              {/* AI Alert Card */}
              <div className="bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-400/30 rounded-2xl p-6 relative overflow-hidden group">
                <div className="relative z-10">
                  <h3 className="font-bold text-lg mb-2 text-indigo-100 flex items-center gap-2 uppercase tracking-tight italic">
                    <AlertTriangle className="w-5 h-5 text-indigo-300" /> Cleanup Alert
                  </h3>
                  <p className="text-sm text-indigo-100/70 leading-relaxed mb-6">
                    AI identified <span className="text-white font-bold underline decoration-indigo-400">4.2 GB</span> of stale temporary cache data from uninstalled packages.
                  </p>
                  <button className="w-full py-2.5 bg-indigo-500/40 hover:bg-indigo-500/60 border border-indigo-400/50 rounded-xl text-xs font-bold uppercase tracking-widest transition-all">
                    Wipe Stale Data
                  </button>
                </div>
                <Trash2 className="absolute right-[-20px] bottom-[-20px] w-32 h-32 text-indigo-500/10 group-hover:scale-110 transition-transform" />
              </div>

              {/* Selection Detail */}
              <AnimatePresence mode="wait">
                {selectedProcess ? (
                  <motion.div 
                    key="selection"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="glass-panel p-6 border-cyan-500/20 bg-cyan-900/5"
                  >
                    <div className="flex justify-between items-start mb-6">
                       <h2 className="text-xl font-bold tracking-tight text-white mb-1">{selectedProcess.name}</h2>
                       <button onClick={() => setSelectedProcess(null)} className="text-white/20 hover:text-white transition-colors">×</button>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-6">
                       <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                          <p className="label-caps mb-1">PID</p>
                          <p className="text-lg font-bold font-mono">{selectedProcess.pid}</p>
                       </div>
                       <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                          <p className="label-caps mb-1">RAM</p>
                          <p className="text-lg font-bold font-mono">{(selectedProcess.memory / 1024).toFixed(1)} GB</p>
                       </div>
                    </div>
                    <div className="space-y-6">
                      <div>
                        <h4 className="label-caps mb-2 text-cyan-400">Expert Analysis</h4>
                        <p className="text-xs text-white/60 leading-relaxed italic border-l-2 border-cyan-500/30 pl-3">
                          {selectedProcess.description || (isAnalyzing ? "Scanning fleet database..." : "No analysis cached. Request audit.")}
                        </p>
                      </div>
                      <button className="w-full py-3 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 rounded-xl text-[10px] font-bold uppercase tracking-[0.2em] transition-all flex items-center justify-center gap-2">
                        Terminate Process
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <div key="empty" className="glass-panel p-10 flex flex-col items-center justify-center text-center opacity-30 italic">
                    <Monitor className="w-12 h-12 mb-4 opacity-10" />
                    <p className="text-xs">Select a process from the explorer to view deep-dive AI metrics</p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Footer Info Bar */}
        <footer className="h-12 border-t border-white/10 px-8 flex items-center justify-between bg-white/5 text-[9px] uppercase tracking-[0.3em] font-bold text-white/30">
          <div>Pulse V4.2.1-Stable</div>
          <div className="flex gap-8">
            <span>Optimized: 12.8GB (WK)</span>
            <span>Uptime: 04:22:15</span>
          </div>
        </footer>
      </div>

      {/* Connection Instructions Modal */}
      <AnimatePresence>
        {showAgentModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="max-w-2xl w-full glass-main p-6 md:p-10 my-8 flex flex-col max-h-[90vh]"
            >
              <div className="flex justify-between items-center mb-8 flex-shrink-0">
                <h2 className="text-2xl font-bold flex items-center gap-4 italic tracking-tight uppercase">
                  <Terminal className="text-cyan-400" /> Local Agent Sync
                </h2>
                <button onClick={() => setShowAgentModal(false)} className="text-white/20 hover:text-white text-3xl">×</button>
              </div>
              
              <div className="space-y-6 overflow-y-auto flex-1 pr-2 custom-scrollbar">
                <p className="text-white/50 text-sm leading-relaxed">
                  Run this lightweight Python script on your desktop to pipe performance metrics into this glass interface. It handles real-time sync of CPU, RAM, and running processes.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button 
                    onClick={downloadWindowsApp}
                    className="flex flex-col items-center justify-center p-6 bg-cyan-500/10 border border-cyan-500/20 rounded-2xl hover:bg-cyan-500/20 transition-all group"
                  >
                    <div className="relative mb-3 group-hover:scale-110 transition-transform">
                      <Monitor className="w-10 h-10 text-cyan-400" />
                      <div className="absolute -bottom-1 -right-1 bg-cyan-500 rounded-full p-0.5 text-[8px] font-black text-slate-900 border border-slate-900 uppercase">EXE</div>
                    </div>
                    <span className="text-xs font-bold uppercase tracking-widest text-cyan-50">One-Click Launcher</span>
                    <span className="text-[8px] text-cyan-400/60 mt-1 uppercase font-bold tracking-tighter">Recommended for Windows</span>
                  </button>
                  <div className="p-6 bg-white/5 border border-white/5 rounded-2xl flex flex-col justify-center">
                    <p className="text-[10px] text-white/40 uppercase font-bold mb-2">Prerequisites</p>
                    <ul className="text-[10px] text-white/60 space-y-1 font-mono">
                      <li>• Windows OS</li>
                      <li>• Python 3.x Installed</li>
                    </ul>
                    <button 
                      onClick={downloadAgent}
                      className="mt-4 text-[9px] uppercase font-bold text-white/20 hover:text-cyan-400 transition-colors flex items-center gap-2"
                    >
                      <Terminal className="w-3 h-3" />
                      Download .py Source Instead
                    </button>
                    <button 
                      onClick={downloadUninstaller}
                      className="mt-2 text-[9px] uppercase font-bold text-red-500/30 hover:text-red-400 transition-colors flex items-center gap-2"
                    >
                      <Trash2 className="w-3 h-3" />
                      Download Uninstaller
                    </button>
                  </div>
                </div>

                <div className="p-5 bg-black/50 rounded-2xl font-mono text-xs border border-white/10 text-cyan-400/80 relative group">
                  <pre className="whitespace-pre-wrap break-all">{agentScript(window.location.origin)}</pre>
                  <button 
                    onClick={() => navigator.clipboard.writeText(agentScript(window.location.origin))}
                    className="absolute top-3 right-3 px-3 py-1.5 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 rounded-lg text-[10px] font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    Copy Source
                  </button>
                </div>
                
                <div className="flex items-center gap-3 text-[10px] uppercase tracking-widest font-bold text-white/30 italic">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> 
                  Verified AES-encrypted pipeline
                </div>
              </div>

              <button 
                onClick={() => setShowAgentModal(false)}
                className="mt-10 w-full py-4 bg-white/5 border border-white/10 hover:bg-white/10 text-white font-bold rounded-2xl transition-colors uppercase tracking-[0.2em] text-xs flex-shrink-0"
              >
                Close Connection Portal
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cleaning Notification */}
      <AnimatePresence>
        {cleaningStatus && (
          <motion.div 
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="fixed bottom-12 left-1/2 -track-x-1/2 px-8 py-4 bg-cyan-500 text-slate-900 rounded-full font-bold text-xs uppercase tracking-[0.2em] shadow-2xl flex items-center gap-4 z-[100] -ml-[150px]"
          >
            <RefreshCcw className="w-4 h-4 animate-spin" />
            {cleaningStatus}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatCard({ icon, label, value, subtext }: { icon: ReactNode, label: string, value: string, subtextText?: string, subtext: string }) {
  return (
    <div className="glass-panel p-6 group hover:bg-white/5 transition-all">
       <div className="flex items-start justify-between mb-4">
         <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/5 flex items-center justify-center transition-colors group-hover:border-white/20">
            {icon}
         </div>
       </div>
       <div className="space-y-1">
         <p className="label-caps">
           {label}
         </p>
         <h2 className="text-3xl font-bold tracking-tight">{value}</h2>
         <p className="text-[10px] text-white/40 uppercase font-medium tracking-wider">
           {subtext}
         </p>
       </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    safe: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    system: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
    suspicious: "bg-red-500/10 text-red-400 border-red-500/20",
    unknown: "bg-white/5 text-white/40 border-white/10",
    idle: "bg-white/5 text-white/20"
  };

  return (
    <span className={cn(
      "px-2 py-1 rounded text-[9px] font-bold uppercase border tracking-widest",
      styles[status] || styles.unknown
    )}>
      {status}
    </span>
  );
}

const agentScript = (url: string) => `import psutil
import requests
import time
import json

API_URL = "${url}/api/report"

def gather_data():
    memory = psutil.virtual_memory()
    processes = []
    
    # Get top 30 memory-heavy processes
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
        try:
            info = proc.info
            processes.append({
                "pid": info['pid'],
                "name": info['name'],
                "cpu": info['cpu_percent'],
                "memory": info['memory_info'].rss / (1024 * 1024) # MB
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
            
    return {
        "os": "Windows/Machine",
        "cpuUsage": psutil.cpu_percent(interval=1),
        "memory": {
            "total": memory.total / (1024 * 1024),
            "used": memory.used / (1024 * 1024),
            "percent": memory.percent
        },
        "processes": sorted(processes, key=lambda x: x['memory'], reverse=True)[:50]
    }

print(f"Connecting to PC Pulse at {API_URL}...")

while True:
    try:
        data = gather_data()
        requests.post(API_URL, json=data)
        time.sleep(2)
    except Exception as e:
        print(f"Sync error: {e}")
        time.sleep(5)`;
